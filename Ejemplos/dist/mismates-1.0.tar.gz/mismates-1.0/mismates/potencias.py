def cuadrado(x):
    return x*x

def cubo(x):
    return x*x*x
