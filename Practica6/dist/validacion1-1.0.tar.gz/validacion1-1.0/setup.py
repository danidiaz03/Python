from setuptools import setup

setup(
    name="validacion1",
    version=1.0,
    description="Algunas validaciones",
    packages=["Modulos"]
    )